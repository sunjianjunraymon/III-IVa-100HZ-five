clear
clc
load('data_set_IVa_ay.mat');
