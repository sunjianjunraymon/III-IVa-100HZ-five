clear
clc
load('data_set_IVa_al_mat\100Hz\data_set_IVa_al.mat');
